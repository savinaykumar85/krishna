 <?php include('header.php'); ?>

	<!-- Banner Section -->
	<div id="page-banner" class="page-banner faq-banner container-fluid no-padding">
		<div class="banner-content">
			<h3>Frequently Asked Questions</h3>
			<ol class="breadcrumb">
				<li><a href="#">Home</a></li>
				<li><a href="#">Services</a></li>
				<li><a href="#">FAQ - Default</a></li>
			</ol>
		</div>
	</div><!-- Banner Section /- -->
	
	<!-- Faq-1 Section -->
	<div id="faq-section" class="faq-section container-fluid no-padding">
		<div class="section-padding"></div>
		<!-- Container -->
		<div class="container">
			<div class="col-md-8 col-sm-8">
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading1">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent1" aria-expanded="true">
								  Its like a kind of torture to have to watch the show?
								</a>
							</h4>
						</div>
						<div id="faqcontent1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="faqheading1">
							<div class="panel-body">
								Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading2">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent2" aria-expanded="false">
								  Friendly neighbors there that's where we meet?
								</a>
							</h4>
						</div>
						<div id="faqcontent2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading2">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading3">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent3" aria-expanded="false">
								Got a dream and just know now we're gonna make our dream come true?
								</a>
							</h4>
						</div>
						<div id="faqcontent3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading3">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading4">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent4" aria-expanded="false">
								These men promptly escaped from a maximum security stockade?
								</a>
							</h4>
						</div>
						<div id="faqcontent4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading4">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading5">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent5" aria-expanded="false">
								some food and up through the ground came a bubbling crude?
								</a>
							</h4>
						</div>
						<div id="faqcontent5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading5">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading6">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent6" aria-expanded="false">
								Then one day he was shootin' at some food and up through the ground?
								</a>
							</h4>
						</div>
						<div id="faqcontent6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading6">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading7">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent7" aria-expanded="false">
								me and the card attached would say thank you for being a friend?
								</a>
							</h4>
						</div>
						<div id="faqcontent7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading7">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading8">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent8" aria-expanded="false">
								Now were up in the big leagues getting' our turn at bat?
								</a>
							</h4>
						</div>
						<div id="faqcontent8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading8">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading9">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent9" aria-expanded="false">
								Now the world don't move to the beat of just one drum?
								</a>
							</h4>
						</div>
						<div id="faqcontent9" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading9">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="faqheading10">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#faqcontent10" aria-expanded="false">
								Here's the story of a man named Brady who was busy with three boys?
								</a>
							</h4>
						</div>
						<div id="faqcontent10" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqheading10">
							<div class="panel-body">
							Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.
							</div>
						</div>
					</div>
					
				</div>
				<div class="section-padding"></div>
			</div>
			<div class="widget-area col-md-4 col-sm-4">
				<aside class="widget widget-search">
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Search...">
						<span class="input-group-btn">
							<button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
						</span>
					</div>
				</aside>
				<aside class="widget widget-catagories">
					<div class="widget-heading">
						<h3>catagories</h3>
					</div>
					<ul>
						<li><i class="fa fa-angle-right"></i><a href="#">Ground Transport<span>(15)</span></a></li>
						<li><i class="fa fa-angle-right"></i><a href="#">Sea Freight<span>(18)</span></a></li>
						<li><i class="fa fa-angle-right"></i><a href="#">Shipment Contracts<span>(22)</span></a></li>
						<li><i class="fa fa-angle-right"></i><a href="#"> Railway Logistics<span>(14)</span></a></li>
						<li><i class="fa fa-angle-right"></i><a href="#">Long Road Trucking<span>(32)</span></a></li>
					</ul>
				</aside>
				<aside class="widget widget-posts">
					<div class="widget-heading">
						<h3>Recent Posts</h3>
					</div>
					<div class="recent-content">
							<img src="images/blog/blog-5.jpg" alt="Blog" />
							<h3><a href="single-blog.php">poor mountaineer barely kept his family fed</a></h3>
							<span><a href="#">July 07, 2015</a></span>
						</div>
						<div class="recent-content">
							<img src="images/blog/blog-6.jpg" alt="Blog" />
							<h3><a href="single-blog.php">card attached would say thank you for being </a></h3>
							<span><a href="single-blog.php">July 07, 2015</a></span>
						</div>
						<div class="recent-content">
							<img src="images/blog/blog-7.jpg" alt="Blog" />
							<h3><a href="single-blog.php">tell me how to get how to get to Sesame Street</a></h3>
							<span><a href="#">July 07, 2015</a></span>
						</div>
				</aside>
				<aside class="widget widget-catagories">
					<div class="widget-heading">
						<h3>Recent Posts</h3>
					</div>
					<ul>
						<li><i class="fa fa-angle-right"></i><a href="#">January<span>(15)</span></a></li>
						<li><i class="fa fa-angle-right"></i><a href="#">February<span>(18)</span></a></li>
						<li><i class="fa fa-angle-right"></i><a href="#">March<span>(22)</span></a></li>
						<li><i class="fa fa-angle-right"></i><a href="#">April<span>(14)</span></a></li>
						<li><i class="fa fa-angle-right"></i><a href="#">May<span>(32)</span></a></li>
					</ul>
				</aside>
				<aside class="widget widget-tag">
					<div class="widget-heading">
						<h3>Populer tags</h3>
					</div>
					<a href="#" title="Tags">Tags</a>
					<a href="#" title="Seaway">Seaway</a>
					<a href="#" title="Roadway">Roadway</a>
					<a href="#" title="Cargo">Cargo</a>
					<a href="#" title="Large Logistics">Large Logistics</a>
					<a href="#" title="Railway">Railway</a>
					<a href="#" title="Shipment">Shipment</a>
					<a href="#" title="Air Freight">Air Freight</a>
					<a href="#" title="Delivery">Delivery</a>
				</aside>
			</div>
		</div><!-- Container /- -->
		<div class="section-padding"></div>
	</div><!-- Faq Section /- -->
		
	
	
	<?php include('footer.php'); ?>