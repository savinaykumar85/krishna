hii
<?php
$json_arr = array( 
"type" => "errornot", 
"text" => "Please enter valid email address!" );

return $json_arr;
?>