 <?php include('header.php'); ?>
	<!-- Banner Section -->
	<div id="page-banner" class="page-banner services-banner container-fluid no-padding">
		<div class="banner-content">
			<h3>Our Services</h3>
			<ol class="breadcrumb">
				<li><a href="#">Home</a></li>
				<li><a href="#">Services</a></li>
			</ol>
		</div>
	</div><!-- Banner Section /- -->
	
	<!-- Services -->
	<div class="services container-fluid no-padding">
		<!-- Container -->
		<div class="section-padding"></div>
		<div class="container">
		
			<!-- Section Header -->
			<div class="section-header-1">
				<h3>Service We Offer</h3>
				<p>Buzz analytics business-to-consumer. Partner network ramen social media freemium iteration.</p>
			</div><!-- Section Header -->
			<div class="services-box services-box-1">
				<div class="col-md-12">
					<div class="services-content">
						<img src="images/services-image/service-1.jpg" alt="services" />
						<h3>Ground Shipping</h3>
						<p>Business model canvas metri essar. Incubator ramen virality product management drect mailing founders gamification Effct Touch.</p>
						<a href="#">Learn More<i class="fa fa-caret-right"></i></a>
					</div>
				</div>
				<div class="col-md-12">
					<div class="services-content">
						<img src="images/services-image/service-2.jpg" alt="services" />
						<h3>Air Delivery</h3>
						<p>Business model canvas metri essar. Incubator ramen virality product management drect mailing founders gamification Effct Touch.</p>
						<a href="#">Learn More<i class="fa fa-caret-right"></i></a>
					</div>
				</div>
				<div class="col-md-12">
					<div class="services-content">
						<img src="images/services-image/service-3.jpg" alt="services" />
						<h3>Sea Delivery</h3>
						<p>Business model canvas metri essar. Incubator ramen virality product management drect mailing founders gamification Effct Touch.</p>
						<a href="#">Learn More<i class="fa fa-caret-right"></i></a>
					</div>
				</div>
				<div class="col-md-12">
					<div class="services-content">
						<img src="images/services-image/service-3.jpg" alt="services" />
						<h3>Sea Delivery</h3>
						<p>Business model canvas metri essar. Incubator ramen virality product management drect mailing founders gamification Effct Touch.</p>
						<a href="#">Learn More<i class="fa fa-caret-right"></i></a>
					</div>
				</div>
				<div class="col-md-12">
					<div class="services-content">
						<img src="images/services-image/service-3.jpg" alt="services" />
						<h3>Sea Delivery</h3>
						<p>Business model canvas metri essar. Incubator ramen virality product management drect mailing founders gamification Effct Touch.</p>
						<a href="#">Learn More<i class="fa fa-caret-right"></i></a>
					</div>
				</div>
				<div class="col-md-12">
					<div class="services-content">
						<img src="images/services-image/service-3.jpg" alt="services" />
						<h3>Sea Delivery</h3>
						<p>Business model canvas metri essar. Incubator ramen virality product management drect mailing founders gamification Effct Touch.</p>
						<a href="#">Learn More<i class="fa fa-caret-right"></i></a>
					</div>
				</div>
			</div>
		</div><!-- Container /- -->
	</div><!-- Services /- -->
	
	<!-- Why We Are Section -->
	<div id="why-we-are-section" class="why-we-are-section container-fluid no-padding">		
		<!-- Features Block -->
		<div class="features-block">
			<div class="section-padding"></div>
			<!-- Section Header -->
			<div class="section-header">
				<h3>Why we are best</h3>
				<p>Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain. Completely synergize resource taxing via premier niche markets. Professionally cultivate one-to-one customer .</p>
				<a href="#" class="btn">About More <i><img src="images/icon/about-ic.png" alt="About Ic" /></i></a>
			</div><!-- Section Header /- -->
			<!-- Features Content -->
			<div class="features-content row">
				<div class="col-md-4 features-box">
					<i><img src="images/icon/commitment.png" alt="commitment" /><span>1</span></i>
					<div class="features-box-content">
						<h4>Quality Commitment</h4>
						<p>Incubator viral prood management mailin such a founders.</p>
					</div>
				</div>
				<div class="col-md-4 features-box">
					<i><img src="images/icon/user.png" alt="commitment" /><span>2</span></i>
					<div class="features-box-content">
						<h4>Quality Commitment</h4>
						<p>Incubator viral prood management mailin such a founders.</p>
					</div>
				</div>
				<div class="col-md-4 features-box">
					<i><img src="images/icon/like.png" alt="commitment" /><span>3</span></i>
					<div class="features-box-content">
						<h4>Quality Commitment</h4>
						<p>Incubator viral prood management mailin such a founders.</p>
					</div>
				</div>
			</div><!-- Features Content /- -->
			<div class="section-padding"></div>
		</div><!-- Features Block -->
		<!-- Request Quote -->
		<div class="request-quote">
			<div class="section-padding"></div>
			<!-- Section Header -->
			<div class="section-header">
				<i><img src="images/icon/quote-ic.png" alt="quote ic" /></i>
				<h3>Request a quote</h3>
				<p>Fill in the form below and we will get back to you ASAP.</p>
			</div><!-- Section Header /- -->
			<form class="quote-form">
				<div class="form-group col-md-6">
					<input type="text" class="form-control" placeholder="Your Name Here">
				</div>
				<div class="form-group col-md-6">
					<input type="text" class="form-control" placeholder="Subject" required>
				</div>
				<div class="form-group col-md-6">
					<input type="text" class="form-control" placeholder="Email Address">
				</div>
				<div class="form-group col-md-6">
					<select>
						<option>Storage</option>
						<option>100</option>
						<option>2000</option>
						<option>30000</option>
					</select>
				</div>
				<div class="form-group col-md-12">
					<textarea class="form-control" placeholder="Message"></textarea>
				</div>
				<div class="form-group col-md-6">
					<label>
						<input type="checkbox"> Get Latest News
					</label>
				</div>
				<div class="form-group col-md-6">
					<button class="btn pull-right">Send Request <i><img src="images/icon/mail-ic.png" alt="About Ic" /></i></button>
				</div>
			</form>
			<div class="section-padding"></div>
		</div><!-- Request Quote /- -->
	</div><!-- Why We Are /- -->
	
	<!-- Offer -->
	<div class="offer container-fluid no-padding">
		<div class="section-padding"></div>
		<!-- Container -->
		<div class="container">
			<!-- Section Header -->
			<div class="section-header">
				<h3>Service We Offer</h3>
				<p>Buzz analytics business-to-consumer. Partner network ramen social media freemium iteration.</p>
			</div><!-- Section Header -->
			<div class="col-md-4 col-sm-6 no-left-padding">
				<img src="images/offer-image/offer-2.jpg" alt="offer-image">
			</div>
			<div class="col-md-8 col-sm-6">
				<div class="row">
					<div class="col-md-6">
						<div class="offers-content">
							<img src="images/icon/icons-1.png" alt="icons">
							<h3>world wide transport</h3>
							<p>Canvas metri essar. Incubator ramen viral product management drect mailing. such founders gamification Effct.</p>
						</div>
					</div>
					<div class="col-md-6">	
						<div class="offers-content">
							<img src="images/icon/icons-3.png" alt="icons">
							<h3>world wide transport</h3>
							<p>Canvas metri essar. Incubator ramen viral product management drect mailing. such founders gamification Effct.</p>
						</div>
					</div>
					<div class="col-md-6">	
						<div class="offers-content">
							<img src="images/icon/icons-2.png" alt="icons">
							<h3>world wide transport</h3>
							<p>Canvas metri essar. Incubator ramen viral product management drect mailing. such founders gamification Effct.</p>
						</div>
					</div>
					<div class="col-md-6">	
						<div class="offers-content">
							<img src="images/icon/icons-4.png" alt="icons">
							<h3>world wide transport</h3>
							<p>Canvas metri essar. Incubator ramen viral product management drect mailing. such founders gamification Effct.</p>
						</div>
					</div>
				</div>
			</div>
		</div><!-- Container / -->
		<div class="section-padding"></div>
	</div><!-- Offer / -->
	
	<!-- Partners Section -->
	<div class="partners-section partner-bg container-fluid no-padding">
		<div class="section-padding"></div>
		<!-- Container -->
		<div class="container">
			<!-- Section Header -->
			<div class="section-padding"></div>
			<div class="section-header">
				<h3>Our Precious Clients</h3>
				<p> Ducimus qui blanditis praesentum voluptaum deleniti atque corrupti quos dolores.</p>
			</div><!-- Section Header -->			
			<div class="partners-logos">
				<div class="item"><a href="#" title="Logo"><img src="images/logos/logo-1.png" alt="Logo 1" /></a></div>
				<div class="item"><a href="#" title="Logo"><img src="images/logos/logo-2.png" alt="Logo 2" /></a></div>
				<div class="item"><a href="#" title="Logo"><img src="images/logos/logo-3.png" alt="Logo 3" /></a></div>
				<div class="item"><a href="#" title="Logo"><img src="images/logos/logo-4.png" alt="Logo 4" /></a></div>
				<div class="item"><a href="#" title="Logo"><img src="images/logos/logo-5.png" alt="Logo 5" /></a></div>
			</div>
		</div><!-- Container / -->
		<div class="section-padding"></div>
	</div><!-- PartnersSection / -->
		
	
	<?php include('footer.php'); ?>